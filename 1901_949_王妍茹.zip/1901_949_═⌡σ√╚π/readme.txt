tomcat  版本 8.5.71
mysql   版本 8.0.27
http://localhost:8081/travel/
管理员登录账号：123  密码：123
用户1登录账号：1234  密码：2345
用户2登录账号：1256  密码：2345
用户3登录账号：tygdfhthj  密码：12345efewf
用户4登录账号：wer12345  密码：12345efewf